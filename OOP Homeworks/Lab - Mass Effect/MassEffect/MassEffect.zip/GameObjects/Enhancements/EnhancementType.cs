﻿namespace MassEffect.GameObjects.Enhancements
{
    public enum EnhancementType
    {
        ThanixCannon,
        KineticBarrier,
        ExtendedFuelCells
    }
}
