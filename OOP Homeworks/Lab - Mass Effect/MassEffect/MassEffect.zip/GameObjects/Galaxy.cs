﻿namespace MassEffect.GameObjects
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using MassEffect.Engine;
    using MassEffect.Exceptions;
    using MassEffect.GameObjects.Locations;
    using MassEffect.Interfaces;

    public class Galaxy
    {
        public HashSet<StarSystem> StarSystems { get; set; }

        public Galaxy()
        {
            this.StarSystems = new HashSet<StarSystem>();
        }

        public StarSystem GetStarSystemByName(string name)
        {
            return this.StarSystems
                .First(s => s.Name == name);
        }

        public void TravelTo(IStarship ship, StarSystem destination)
        {
            var startLocation = ship.Location;
            if (!startLocation.NeighbourStarSystems.ContainsKey(destination))
            {
                throw new LocationOutOfRangeException(string.Format(
                    "Cannot travel directly from {0} to {1}",
                    startLocation.Name, destination.Name));
            }

            double requiredFuel = startLocation.NeighbourStarSystems[destination];
            if (ship.Fuel < requiredFuel)
            {
                throw new InsufficientFuelException(string.Format(
                    "Not enough fuel to travel to {0} - {1}/{2}", 
                    destination.Name, ship.Fuel, requiredFuel));
            }

            Console.WriteLine(Messages.ShipTraveled, ship.Name, ship.Location.Name, destination.Name);

            ship.Fuel -= requiredFuel;
            ship.Location = destination;
        }
    }
}
